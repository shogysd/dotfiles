if [ "$(uname 2>&1)" = "Darwin" ]; then
    # macOS
    :
else
    # Linux
    :
fi
